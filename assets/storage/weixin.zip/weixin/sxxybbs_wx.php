<?php
/**
  * wechat php test
  */

//define your token
define("TOKEN", "wwwsxxybbscom");
$wechatObj = new wechatCallbackapiTest();
//$wechatObj->valid();
$wechatObj->responseMsg();
class wechatCallbackapiTest
{
	public function valid()
    {
        $echoStr = $_GET["echostr"];

        //valid signature , option
        if($this->checkSignature()){
        	echo $echoStr;
        	exit;
        }
    }

    public function responseMsg()
    {
		//get post data, May be due to the different environments
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

      	//extract post data
		if (!empty($postStr)){
                
              	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
				$fromUsername = $postObj->FromUserName;
                $toUsername = $postObj->ToUserName;
				$time = time();
				
				if($postObj->Content == '1'){
					$textTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>"; 
					$msgType = 'text';
					$contentStr = "你输入了：1";
					$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                	echo $resultStr;
				
				}else if($postObj->Content == '抽奖'){
						$newsTpl ="<xml>
									<ToUserName><![CDATA[%s]]></ToUserName>
									<FromUserName><![CDATA[%s]]></FromUserName>
									<CreateTime>%s</CreateTime>
									<MsgType><![CDATA[news]]></MsgType>
									<ArticleCount>1</ArticleCount>
									<Articles>
									<item>
									<Title><![CDATA[刮刮乐翻天]]></Title> 
									<Description><![CDATA[我就要去刮刮乐，抽奖去！]]></Description>
									<PicUrl><![CDATA[http://special.sxcq.cn/cj/weixin/ggk/ggk.jpg]]></PicUrl>
									<Url><![CDATA[%s]]></Url>
									</item>
									</Articles>
									<FuncFlag>0</FuncFlag>
								  </xml>";
								  
					$url="http://special.sxcq.cn/cj/weixin/ggk/prize.php";
                	$resultStr = sprintf($newsTpl, $fromUsername, $toUsername, $time,$url);
                	echo $resultStr;
				
				}else{
                $keyword = trim($postObj->Content);
                $textTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";             
				if(!empty( $keyword ))
                {
              		$msgType = "text";
                	$contentStr = "请输入：’1‘或者‘抽奖’";
                	$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                	echo $resultStr;
                }else{
                	$msgType = "text";
                	$contentStr = "谢谢你关注sxxybbs博客，后续有精彩的内容会第一时间发送给您！回复：’1‘或者‘抽奖’得到对应的服务";
                	$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                	echo $resultStr;
                }
				}

        }else {
        	echo "";
        	exit;
        }
    }
		
	private function checkSignature()
	{
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];	
        		
		$token = TOKEN;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		
		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}
}

?>