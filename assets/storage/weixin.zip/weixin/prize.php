<?php
$rand = rand(1,100);
if($rand<10){
	$prize = '一等奖';
}else if($rand<30){
	$prize = '二等奖';
}else if($rand<60){
	$prize = '三等奖';
}else{
	$prize = '谢谢参与';
}

?>

<!DOCTYPE html>
<html>
	<head>
		<base href="http://www.apiwx.com/" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="format-detection" content="telephone=no">
		<title>刮刮卡</title>
		<link href="index/css/activity-style.css" rel="stylesheet" type="text/css">
	</head>
	
	</head>
	<body data-role="page" class="activity-scratch-card-winning">
		<script src="index/js/jquery.js" type="text/javascript"></script>
		<script src="index/js/wScratchPad.js" type="text/javascript"></script>
		<div class="main">
			<div class="cover">
				<img src="index/images/activity/activity-scratch-card-bannerbg.png">
				<div id="prize"><?php echo $prize;?></div>
				<div id="scratchpad">
				</div>
			</div>
	
				<div class="boxcontent boxwhite">
					<div class="box">
						<div class="title-brown">
							<span>
								奖项设置：
							</span>
						</div>
						<div class="Detail">
							<p>
								一等奖： iphone 5S 奖品数量：60
							</p>
							<p>
								二等奖： ipad mini2 奖品数量：100
							</p>
							<p>
								三等奖： 金士顿16G手机卡 奖品数量：2000
							</p>
						</div>
					</div>
				</div>
				
				<div class="boxcontent boxwhite">
					<div class="box">
						<div class="title-brown">
							活动说明：
						</div>
						<div class="Detail">
							<p class="red">
								中奖用户请准确将收货地址发送给我，我们将以货到付款的方式邮寄给你！
							</p>
							<p>
								亲，祝您好运哦！<a href="http://special.sxcq.cn/cj/weixin/ggk/prize.php">再来一次</a>
							</p>
						</div>
					</div>
				</div>
			</div>
			<div style="clear:both;">
			</div>
		</div>
		
		<script type="text/javascript">
			window.sncode = "null";
			$(function() {
				$("#scratchpad").wScratchPad({
					width: 150,
					height: 40,
					color: "#a9a9a7",
					
				});
			});
		</script>
		
	</body>

</html>